
export type CBOptions = {
	className	?:string,
	title		?:string,
	html		?: (data:CBOptions) => string,
}
